---
name: ⛔ Documentation & Examples
about: Issues with the Documentation and/or the Examples
labels: docs

---

<!-- 
We have our own dedicated repository for the examples. Please open your
documentation-related issue at https://github.com/wenzhixin/bootstrap-table-examples
-->


**Description**  
<!-- Description of issue with the documentation. -->


<!-- Love bootstrap-table? Please consider supporting our collective:
👉  https://opencollective.com/bootstrap-table/donate -->